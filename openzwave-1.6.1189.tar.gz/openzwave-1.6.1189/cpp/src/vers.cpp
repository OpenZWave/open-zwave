#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 6;
uint16_t ozw_vers_revision = 1189;
char ozw_version_string[] = "1.6-1189-g6743b15b-dirty";

#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 6;
uint16_t ozw_vers_revision = 1185;
char ozw_version_string[] = "1.6-1185-g0dba812c-dirty";
